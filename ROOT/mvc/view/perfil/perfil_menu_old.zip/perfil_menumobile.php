<div class="dropdown bordersquared noOpacity" style="height: 100%;">

			<button class="btn bg-btn-green bordersquared border0px dropdown-toggle greenShadow noOpacity" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-cogs"></i></button>

			<div class="bg-green dropdown-menu dropdown-menu-right dropleft bordersquared padding0px noOpacity" aria-labelledby="dropdownMenuButton">
				<button class="dropdown-item dropdown-toggle btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-plus-circle"></i> Cadastros</button>

				<div class="dropdown-menu bordersquared padding0px noOpacity" aria-labelledby="dropdownMenuButton">

					<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/addmembro.php')" href="#"><i class="fas fa-user-plus"></i> Membros</button>

					<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/addinstru.php')" href="#"><i class="fas fa-drum"></i> Instrumentos</button>

					<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/addcargo.php')" href="#"><i class="fas fa-user-tie"></i> Cargos</button>

					<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/addvertente.php')" href="#"><i class="fas fa-box"></i> Vertentes</button>

					<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/espetaculos.php')" href="#"><i class="fas fa-star"></i> Espetáculos</button>

				</div>
				<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/parametros.php')" href="#"><i class="fas fa-cogs"></i> Parâmetros</button>

				<button class="dropdown-item btn bg-btn-green bordersquared bottomborder greenShadow noOpacity" onclick="carregar('../mvc/view/adm/buscamembro.php')" href="#"><i class="far fa-address-card"></i> Membros</button>

			</div>
		</div>