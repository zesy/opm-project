<ul>
	<li class="dropdown navbar-brand">
		<button class="dropdown-toggle btn bg-btn-green bordersquared border0px greenShadow" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-plus-circle"></i> Cadastros</button>
		<div class="bg-green dropdown-menu bordersquared padding0px noOpacity" aria-labelledby="dropdownMenuButton">
			<button class="btn bg-btn-green bordersquared border0px greenShadow dropdown-item" onclick="carregar('../mvc/view/adm/addmembro.php')" href="#"><i class="fas fa-user-plus"></i> Membros</button>
			<button class="btn bg-btn-green bordersquared border0px greenShadow dropdown-item" onclick="carregar('../mvc/view/adm/addinstru.php')" href="#"><i class="fas fa-drum"></i> Instrumentos</button>
			<button class="btn bg-btn-green bordersquared border0px greenShadow dropdown-item" onclick="carregar('../mvc/view/adm/addcargo.php')" href="#"><i class="fas fa-user-tie"></i> Cargos</button>
			<button class="btn bg-btn-green bordersquared border0px greenShadow dropdown-item" onclick="carregar('../mvc/view/adm/addvertente.php')" href="#"><i class="fas fa-box"></i> Vertentes</button>
			<button class="btn bg-btn-green bordersquared border0px greenShadow dropdown-item" onclick="carregar('../mvc/view/adm/espetaculos.php')" href="#"><i class="fas fa-star"></i> Espetáculos</button>
		</div>
	</li>
	<li class="navbar-brand">
		<button class="btn bg-btn-green bordersquared border0px greenShadow" onclick="carregar('../mvc/view/adm/parametros.php')" href="#"><i style="font-size: 1.2em;" class="fas fa-cogs"></i> Parâmetros</button>
	</li>
	<li class="navbar-brand">
		<button class="btn bg-btn-green bordersquared border0px greenShadow" onclick="carregar('../mvc/view/adm/buscamembro.php')" href="#"><i style="font-size: 1.2em;" class="far fa-address-card"></i> Membros</button>
	</li>
</ul>